from flask import Flask, render_template

app = Flask(__name__)
app.config.from_object("config")

from app.ws.controllers import ws

app.register_blueprint(ws)
